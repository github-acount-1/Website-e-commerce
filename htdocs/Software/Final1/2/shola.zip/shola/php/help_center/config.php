<?php
define('SERVER_NAME', 'localhost');
define('USERNAME', 'root');
define('DB_NAME', 'shola');
