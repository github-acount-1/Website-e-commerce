<?php

	$root = $_SERVER['DOCUMENT_ROOT'];
	if($root[strlen($root) - 1] != "/")
	    $root .= "/";

	require_once $root.'shola/php/includes/helpers_inc.php';
	//require_once ROOT_DIR.'connectDB-inc.php';
	require_once $root.'shola/php/classes/item.class.php';

	$retrievedItems=new ItemClass();
	$items=$retrievedItems->fetchItems($categoryName);
	$display="<ul>";

	while($row=$items->fetchObject()){
		$display.="<form action='' method='post'>
				  <li>
					<img src='$row->ItemImage'/>
					<p><a href='someurl'>$row->Itemname</a></p>
					<input type='submit' value='Buy Now' name='buy' />
				  </li>
				  </form>
				  ";
	}
	return $display;