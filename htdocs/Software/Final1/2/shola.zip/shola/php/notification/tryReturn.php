<?php
require_once 'classes/return_policy.class.php';

ReturnPolicy::processReturn();
