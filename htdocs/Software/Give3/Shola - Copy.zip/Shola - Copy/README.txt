  

  Name                  ID.No             Stream
Belayneh Mathewos     ATR/3742/07      Computer IV