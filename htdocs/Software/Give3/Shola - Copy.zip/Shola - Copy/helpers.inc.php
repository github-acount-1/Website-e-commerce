<?php
	//define("ROOT_DIR", $_SERVER['DOCUMENT_ROOT'].'shola/');//use /shola/	
	define("ROOT_DIR", $_SERVER['DOCUMENT_ROOT'].' /Software/project4/Shola/');
	
?> 

